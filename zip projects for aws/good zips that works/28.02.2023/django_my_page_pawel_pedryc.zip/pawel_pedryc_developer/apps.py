from django.apps import AppConfig


class PawelPedrycDeveloperConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pawel_pedryc_developer'
