const frameHeight = 102;
const frames = 15;
const div = document.getElementById("animation");
let frame = 0;
setInterval(function()
    {
        const frameOffset = (++frame % frames) * -frameHeight;
        div.style.backgroundPosition = "0px " + frameOffset + "px";
    }, 100
);


// console.log("range 10:");
// _.range(10)




// $("#animation").fadeIn(500);




// function anim_logo()
// {
// const frameHeight = 102;
// const frames = 15;
// const div = document.getElementById("animation");
// let frame = 0;
// setInterval(function () {
//     const frameOffset = (++frame % frames) * -frameHeight;
//     div.style.backgroundPosition = "0px " + frameOffset + "px";
// }, 100);
// }